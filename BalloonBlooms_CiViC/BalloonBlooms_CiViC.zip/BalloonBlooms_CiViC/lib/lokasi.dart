// import 'package:baloonblooms/screens/minggu1.dart';        // HOME
// import 'package:baloonblooms/screens/minggu2.dart';        // PRODUCT
// import 'package:baloonblooms/screens/minggu3.dart';        // COMMENT (button, textfield)
// import 'package:baloonblooms/screens/minggu4.dart';        // WISHLIST (state, provider)
// import 'package:baloonblooms/screens/minggu5.dart';        // ADD FEEDBACK (checkbox, radio, chips)
// import 'package:baloonblooms/screens/minggu6.dart';        // NOTIFICATION (switch, dropdownbutton)
// import 'package:baloonblooms/screens/minggu7.dart';        // DETAIL PRODUCT (appbar, floatingactionbutton)
// import 'package:baloonblooms/components/minggu9.dart';     // BURGER MENU, LOGIN (navdrawer, tabbar, bottomsheets), M15 (addingpackager font_awesome_flutter)
// import 'package:baloonblooms/components/minggu10.dart';    // UPDATE APP (banner, dialog, snackbar)
// import 'package:baloonblooms/screens/minggu11.dart';       // ALL FEEDBACK (menu, listview, divider)
// import 'package:baloonblooms/components/minggu12.dart';    // WISHLIST CARD (card, listtile)
// import 'package:baloonblooms/screens/minggu13.dart';       // CUSTOM - SNACK BUDGET (slider, tooltip, progressindicator)
// import 'package:baloonblooms/components/minggu14.dart';    // CUSTOM - SET DATE TIME (date time picker)
// import 'package:baloonblooms/components/minggu15.dart';    // CUSTOM - PORTRAIT ART, HOME CAROUSEL, WEBVIEW INSTAGRAM (imagepicker, carousel, webview)

// import 'package:baloonblooms/main.dart';                      // M07 (bottomnavigation)
// import 'package:baloonblooms/components/product_card.dart';   // M02 (layout)
// import 'package:baloonblooms/screens/image.dart';             // M07, M15 (show image in full screen)
// import 'package:baloonblooms/screens/custom.dart';            // M15 base

// import 'package:baloonblooms/providers/product_provider.dart';         // M02
// import 'package:baloonblooms/providers/comment_provider.dart';         // M03
// import 'package:baloonblooms/providers/wishlist_provider.dart';        // M04
// import 'package:baloonblooms/providers/feedback_provider.dart';        // M05
// import 'package:baloonblooms/providers/notification_provider.dart';    // M06
// import 'package:baloonblooms/providers/login_provider.dart';           // M09
// import 'package:baloonblooms/providers/custom_provider.dart';          // M13, M14, M15